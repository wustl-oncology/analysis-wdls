version 1.0

workflow pvacsplice_workflow {
  input {
    Int n_threads = 8
    File input_vcf
    File input_vcf_tbi
    File input_regtools_tsv
    File input_reference_dna_fasta
    File input_reference_gtf
    String sample_name
    Array[String] alleles
    Array[String] prediction_algorithms
    File? peptide_fasta
    File? genes_of_interest_file

    Array[Int]? epitope_lengths_class_i
    Array[Int]? epitope_lengths_class_ii
    Int? binding_threshold
    Float? binding_percentile_threshold
    Float? presentation_percentile_threshold
    Float? immunogenicity_percentile_threshold
    String? percentile_threshold_strategy
    Int? iedb_retries

    String? normal_sample_name
    String? net_chop_method  # enum [cterm , 20s]
    String? top_score_metric  # enum [lowest, median]
    Array[String]? top_score_metric2
    Float? net_chop_threshold
    String? additional_report_columns  # enum [sample_name]
    Int? fasta_size
    Boolean exclude_nas = false
    Int? normal_cov
    Int? tdna_cov
    Int? trna_cov
    Float? normal_vaf
    Float? tdna_vaf
    Float? trna_vaf
    Float? expn_val
    Int? maximum_transcript_support_level  # enum [1, 2, 3, 4, 5]
    Array[String]? transcript_prioritization_strategy # allowed values ['canonical', 'mane_select', 'tsl']
    Int? aggregate_inclusion_binding_threshold
    Array[String]? problematic_amino_acids
    Array[String]? biotypes
    String? netmhciipan_version # enum [4.3, 4.2, 4.1, 4.0]
    Int? aggregate_inclusion_count_limit

    Int? junction_score
    Int? variant_distance
    Boolean save_gtf = true
    Array[String]? junction_anchor_types

    Boolean allele_specific_binding_thresholds = false
    Boolean keep_tmp_files = false
    Boolean netmhc_stab = false
    Boolean run_reference_proteome_similarity = false
    Boolean allow_incomplete_transcripts =  false

    Float? tumor_purity
  }

  Float input_size = size([input_vcf, input_vcf_tbi, input_regtools_tsv, input_reference_dna_fasta, input_reference_gtf], "GB")
  Int space_needed_gb = 10 + round(input_size)

  call pvacsplice {
    input:
      n_threads = n_threads,
      input_vcf = input_vcf,
      input_vcf_tbi = input_vcf_tbi,
      input_regtools_tsv = input_regtools_tsv,
      input_reference_dna_fasta = input_reference_dna_fasta,
      input_reference_gtf = input_reference_gtf,
      sample_name = sample_name,
      alleles = alleles,
      prediction_algorithms = prediction_algorithms,
      peptide_fasta = peptide_fasta,
      genes_of_interest_file = genes_of_interest_file,
      epitope_lengths_class_i = epitope_lengths_class_i,
      epitope_lengths_class_ii = epitope_lengths_class_ii,
      binding_threshold = binding_threshold,
      binding_percentile_threshold = binding_percentile_threshold,
      presentation_percentile_threshold = presentation_percentile_threshold,
      immunogenicity_percentile_threshold = immunogenicity_percentile_threshold,
      percentile_threshold_strategy = percentile_threshold_strategy,
      iedb_retries = iedb_retries,
      normal_sample_name = normal_sample_name,
      net_chop_method = net_chop_method,
      top_score_metric = top_score_metric,
      top_score_metric2 = top_score_metric2,
      net_chop_threshold = net_chop_threshold,
      additional_report_columns = additional_report_columns,
      fasta_size = fasta_size,
      exclude_nas = exclude_nas,
      normal_cov = normal_cov,
      tdna_cov = tdna_cov,
      trna_cov = trna_cov,
      normal_vaf = normal_vaf,
      tdna_vaf = tdna_vaf,
      trna_vaf = trna_vaf,
      expn_val = expn_val,
      maximum_transcript_support_level = maximum_transcript_support_level,
      aggregate_inclusion_binding_threshold = aggregate_inclusion_binding_threshold,
      problematic_amino_acids = problematic_amino_acids,
      biotypes = biotypes,
      netmhciipan_version = netmhciipan_version,
      aggregate_inclusion_count_limit = aggregate_inclusion_count_limit,
      junction_score = junction_score,
      variant_distance = variant_distance,
      save_gtf = save_gtf,
      junction_anchor_types = junction_anchor_types,
      allele_specific_binding_thresholds = allele_specific_binding_thresholds,
      keep_tmp_files = keep_tmp_files,
      netmhc_stab = netmhc_stab,
      run_reference_proteome_similarity = run_reference_proteome_similarity,
      allow_incomplete_transcripts = allow_incomplete_transcripts,
      tumor_purity = tumor_purity,
      space_needed_gb = space_needed_gb
  }

  output {
    Array[File] mhc_i = pvacsplice.mhc_i
    Array[File] mhc_ii = pvacsplice.mhc_ii
    Array[File] combined = pvacsplice.combined
    File? splice_transcript_combined_report = pvacsplice.splice_transcript_combined_report
    File? splice_fasta = pvacsplice.splice_fasta
    File? splice_fasta_fai = pvacsplice.splice_fasta_fai
    File? splice_gtf = pvacsplice.splice_gtf
    File? mhc_i_log = pvacsplice.mhc_i_log
    File? mhc_ii_log = pvacsplice.mhc_ii_log
    File? mhc_log = pvacsplice.mhc_log
  }
}
task pvacsplice {
  input {
    Int n_threads = 8
    File input_vcf
    File input_vcf_tbi
    File input_regtools_tsv
    File input_reference_dna_fasta
    File input_reference_gtf 
    String sample_name
    Array[String] alleles
    Array[String] prediction_algorithms
    File? peptide_fasta 
    File? genes_of_interest_file

    Array[Int]? epitope_lengths_class_i
    Array[Int]? epitope_lengths_class_ii
    Int? binding_threshold
    Float? binding_percentile_threshold
    Float? presentation_percentile_threshold
    Float? immunogenicity_percentile_threshold
    String? percentile_threshold_strategy
    Int? iedb_retries

    String? normal_sample_name
    String? net_chop_method  # enum [cterm , 20s]
    String? top_score_metric  # enum [lowest, median]
    Array[String]? top_score_metric2
    Float? net_chop_threshold
    String? additional_report_columns  # enum [sample_name]
    Int? fasta_size
    Boolean exclude_nas = false
    Int? normal_cov
    Int? tdna_cov
    Int? trna_cov
    Float? normal_vaf
    Float? tdna_vaf
    Float? trna_vaf
    Float? expn_val
    Int? maximum_transcript_support_level  # enum [1, 2, 3, 4, 5]
    Array[String]? transcript_prioritization_strategy # allowed values ['canonical', 'mane_select', 'tsl']
    Int? aggregate_inclusion_binding_threshold
    Array[String]? problematic_amino_acids
    Array[String]? biotypes
  String? netmhciipan_version # enum [4.3, 4.2, 4.1, 4.0]
    Int? aggregate_inclusion_count_limit
    
    Int? junction_score
    Int? variant_distance
    Boolean save_gtf = false
    Array[String]? junction_anchor_types

    Boolean allele_specific_binding_thresholds = false
    Boolean keep_tmp_files = false
    Boolean netmhc_stab = false
    Boolean run_reference_proteome_similarity = false
    Boolean allow_incomplete_transcripts =  false

    Float? tumor_purity
    Int space_needed_gb
  }

  # Float input_size = size([input_vcf, input_vcf_tbi, input_regtools_tsv, input_reference_dna_fasta,input_reference_gtf], "GB") #input files: annotated vcf, regtools tsv, reference fasta, reference gtf 
  # Int space_needed_gb = 10 + round(input_size) 
  runtime {
    preemptible: 1
    maxRetries: 2
    memory: "32GB"
    cpu: n_threads
    docker: "griffithlab/pvactools:7.0.1"
    disks: "local-disk ~{space_needed_gb} HDD"
  }

  # explicit typing required, don't inline
  Array[Int] epitope_i = select_first([epitope_lengths_class_i, []])
  Array[Int] epitope_ii = select_first([epitope_lengths_class_ii, []])
  Array[String] problematic_aa = select_first([problematic_amino_acids, []])
  Array[String] biotypes_list = select_first([biotypes, []])
  Array[String] transcript_prioritization_strategy_list = select_first([transcript_prioritization_strategy, []])
  Array[String] junction_anchor_types_list = select_first([junction_anchor_types,[]])
  Array[String] tsm2 = select_first([top_score_metric2, []])


  command <<<
    # touch each tbi to ensure they have a timestamp after the vcf
    touch ~{input_vcf_tbi}

    ln -s "$TMPDIR" /tmp/pvacsplice && export TMPDIR=/tmp/pvacsplice && \
    /usr/local/bin/pvacsplice run --iedb-install-directory /opt/iedb \
    --pass-only \
    ~{if defined(tumor_purity) then "--tumor-purity " + select_first([tumor_purity]) else ""} \
    ~{if length(epitope_i ) > 0 then "-e1 " else ""} ~{sep="," epitope_i} \
    ~{if length(epitope_ii) > 0 then "-e2 " else ""} ~{sep="," epitope_ii} \
    ~{if defined(binding_threshold) then "-b ~{binding_threshold}" else ""} \
    ~{if defined(binding_percentile_threshold) then "--binding-percentile-threshold ~{binding_percentile_threshold}" else ""} \
    ~{if defined(presentation_percentile_threshold) then "--presentation-percentile-threshold ~{presentation_percentile_threshold}" else ""} \
    ~{if defined(immunogenicity_percentile_threshold) then "--immunogenicity-percentile-threshold ~{immunogenicity_percentile_threshold}" else ""} \
    ~{if defined(percentile_threshold_strategy) then "--percentile-threshold-strategy ~{percentile_threshold_strategy}" else ""} \
    ~{if allele_specific_binding_thresholds then "--allele-specific-binding-thresholds" else ""} \
    ~{if defined(aggregate_inclusion_binding_threshold) then "--aggregate-inclusion-binding-threshold ~{aggregate_inclusion_binding_threshold}" else ""} \
    ~{if defined(aggregate_inclusion_count_limit) then "--aggregate-inclusion-count-limit ~{aggregate_inclusion_count_limit}" else ""} \
    ~{if defined(iedb_retries) then "-r ~{iedb_retries}" else ""} \
    ~{if keep_tmp_files then "-k" else ""} \
    ~{if defined(normal_sample_name) then "--normal-sample-name ~{normal_sample_name}" else ""} \
    ~{if defined(net_chop_method) then "--net-chop-method ~{net_chop_method}" else ""} \
    ~{if netmhc_stab then "--netmhc-stab" else ""} \
    ~{if run_reference_proteome_similarity then "--run-reference-proteome-similarity" else ""} \
    ~{if defined(peptide_fasta) then "--peptide-fasta ~{peptide_fasta}" else ""} \
    ~{if defined(top_score_metric) then "-m ~{top_score_metric}" else ""} \
    ~{if length(tsm2) > 0 then "--top-score-metric2 " else ""} ~{sep="," tsm2} \
    ~{if defined(net_chop_threshold) then "--net-chop-threshold ~{net_chop_threshold}" else ""} \
    ~{if defined(additional_report_columns) then "-a ~{additional_report_columns}" else ""} \
    ~{if defined(fasta_size) then "-s ~{fasta_size}" else ""} \
    ~{if exclude_nas then "--exclude-NAs" else ""} \
    ~{if defined(normal_cov) then "--normal-cov ~{normal_cov}" else ""} \
    ~{if defined(tdna_cov) then "--tdna-cov ~{tdna_cov}" else ""} \
    ~{if defined(trna_cov) then "--trna-cov ~{trna_cov}" else ""} \
    ~{if defined(normal_vaf) then "--normal-vaf ~{normal_vaf}" else ""} \
    ~{if defined(tdna_vaf) then "--tdna-vaf ~{tdna_vaf}" else ""} \
    ~{if defined(trna_vaf) then "--trna-vaf ~{trna_vaf}" else ""} \
    ~{if defined(expn_val) then "--expn-val ~{expn_val}" else ""} \
    ~{if length(transcript_prioritization_strategy_list) > 0 then "--transcript-prioritization-strategy" else ""} ~{sep="," transcript_prioritization_strategy_list} \
    ~{if defined(maximum_transcript_support_level) then "--maximum-transcript-support-level ~{maximum_transcript_support_level}" else ""} \
    ~{if length(problematic_aa) > 0 then "--problematic-amino-acids" else ""} ~{sep="," problematic_aa} \
    ~{if length(biotypes_list) > 0 then "--biotypes" else ""} ~{sep="," biotypes_list} \
    ~{if allow_incomplete_transcripts then "--allow-incomplete-transcripts" else ""} \
    ~{if defined(genes_of_interest_file) then "--genes-of-interest-file ~{genes_of_interest_file}" else ""} \
    ~{if defined(netmhciipan_version) then "--netmhciipan-version ~{netmhciipan_version}" else ""} \
    ~{if defined(junction_score) then "--junction-score ~{junction_score}" else ""} \
    ~{if defined(variant_distance) then "--variant-distance ~{variant_distance}" else ""} \
    ~{if save_gtf then "-g" else ""} \
    ~{if length(junction_anchor_types_list) > 0 then "--anchor-types" else ""} ~{sep="," junction_anchor_types_list} \
    -t ~{n_threads} \
    ~{input_regtools_tsv} ~{sample_name} ~{sep="," alleles} ~{sep=" " prediction_algorithms} \
    pvacsplice_predictions ~{input_vcf} ~{input_reference_dna_fasta} ~{input_reference_gtf}

    if [[ -e pvacsplice_predictions/MHC_Class_I/log/inputs.yml ]]; then cp pvacsplice_predictions/MHC_Class_I/log/inputs.yml inputs_class_I.yml; fi
    if [[ -e pvacsplice_predictions/MHC_Class_II/log/inputs.yml ]]; then cp pvacsplice_predictions/MHC_Class_II/log/inputs.yml inputs_class_II.yml; fi
    if [[ -e pvacsplice_predictions/log/inputs.yml ]]; then cp pvacsplice_predictions/log/inputs.yml inputs.yml; fi 
  >>>

  # I keep the inputs_class_I.yml and inputs_class_II.yml here, but may delete those in the future if we dont plan to actually add those in pvacsplice output. At the time of writing (pvacsplice ver 6.0.3), there's only 1 log file that combine both class I and class II (inputs.yml). 
  output {
    File? mhc_i_all_epitopes = "pvacsplice_predictions/MHC_Class_I/~{sample_name}.all_epitopes.tsv"
    File? mhc_i_aggregated_report = "pvacsplice_predictions/MHC_Class_I/~{sample_name}.all_epitopes.aggregated.tsv"
    File? mhc_i_filtered_epitopes = "pvacsplice_predictions/MHC_Class_I/~{sample_name}.filtered.tsv"
    File? mhc_i_log = "inputs_class_I.yml"
    File? mhc_ii_all_epitopes = "pvacsplice_predictions/MHC_Class_II/~{sample_name}.all_epitopes.tsv"
    File? mhc_ii_aggregated_report = "pvacsplice_predictions/MHC_Class_II/~{sample_name}.all_epitopes.aggregated.tsv"
    File? mhc_ii_filtered_epitopes = "pvacsplice_predictions/MHC_Class_II/~{sample_name}.filtered.tsv"
    File? mhc_ii_log = "inputs_class_II.yml"
    File? mhc_log = "inputs.yml"
    File? combined_all_epitopes = "pvacsplice_predictions/combined/~{sample_name}.all_epitopes.tsv"
    File? combined_aggregated_report = "pvacsplice_predictions/combined/~{sample_name}.all_epitopes.aggregated.tsv"
    File? combined_filtered_epitopes = "pvacsplice_predictions/combined/~{sample_name}.filtered.tsv"
    File? splice_transcript_combined_report = "pvacsplice_predictions/~{sample_name}_combined.tsv"
    File? splice_gtf = "pvacsplice_predictions/~{sample_name}_gtf.tsv"
    File? splice_fasta = "pvacsplice_predictions/~{sample_name}.transcripts.fa"
    File? splice_fasta_fai = "pvacsplice_predictions/~{sample_name}.transcripts.fa.fai"
    
    # glob documentations
    # https://github.com/openwdl/wdl/blob/main/versions/1.0/SPEC.md#globs
    Array[File] mhc_i = glob("pvacsplice_predictions/MHC_Class_I/*")
    Array[File] mhc_ii = glob("pvacsplice_predictions/MHC_Class_II/*")
    Array[File] combined = glob("pvacsplice_predictions/combined/*")

  }
}
